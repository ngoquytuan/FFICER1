# Quick Start Guide - FF-ICE Filing Service

## Deploy in 5 Minutes (Docker Method)

### Prerequisites
```bash
# Install Docker and Docker Compose
sudo apt update
sudo apt install docker.io docker-compose -y
```

### Deploy
```bash
# 1. Navigate to project directory
cd /path/to/fficeR1

# 2. Start services
sudo docker-compose up -d

# 3. Check status (wait ~30 seconds for startup)
sudo docker-compose ps

# 4. Test health endpoint
curl http://localhost:8080/health
```

### Test API
```bash
# Submit a flight plan
curl -X POST http://localhost:8080/api/v1/filing/submit \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "VN123",
    "departure": "VVNB",
    "arrival": "VVTS",
    "etd": "2025-10-15T02:00:00",
    "eta": "2025-10-15T04:00:00",
    "fixmXml": "<FlightPlan>Test</FlightPlan>"
  }'

# Expected: {"gufi":"...","status":"ACCEPTED",...}
```

## Native Deployment (Production)

### Prerequisites
```bash
# Install Java 17, Maven, and PostgreSQL
sudo apt update
sudo apt install openjdk-17-jdk maven postgresql postgresql-contrib -y
```

### Setup Database
```bash
sudo -u postgres psql << EOF
CREATE USER filing_user WITH PASSWORD 'filing_pass';
CREATE DATABASE filing_db OWNER filing_user;
GRANT ALL PRIVILEGES ON DATABASE filing_db TO filing_user;
EOF
```

### Build and Run
```bash
# Build
mvn clean package -DskipTests

# Run
java -jar target/filing-service-1.0.0.jar

# Test (in another terminal)
curl http://localhost:8080/health
```

## Key Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Health check |
| `/api/v1/filing/submit` | POST | Submit flight plan (REST) |
| `/api/v1/filing/{gufi}` | GET | Retrieve flight plan (REST) |
| `/ws/filing.wsdl` | GET | WSDL definition |
| `/ws` | POST | SOAP endpoint |

## Default Configuration

- **REST API**: http://localhost:8080
- **SOAP API**: http://localhost:8080/ws
- **Database**: PostgreSQL on localhost:5432
  - Database: `filing_db`
  - User: `filing_user`
  - Password: `filing_pass`

## Troubleshooting

```bash
# View application logs (Docker)
sudo docker-compose logs -f filing-service

# View application logs (Native)
# Logs are in console output

# Check database
psql -h localhost -U filing_user -d filing_db -W

# Restart services (Docker)
sudo docker-compose restart

# Stop services (Docker)
sudo docker-compose down
```

## Next Steps

1. Read `DEPLOYMENT_GUIDE.md` for detailed deployment instructions
2. See `README.md` for project overview
3. Check `FFICE_deploy2.md` for full ICAO FF-ICE/R1 specification
4. Implement P6 (Security Layer) for production use

---

**Need help?** Check the full deployment guide in `DEPLOYMENT_GUIDE.md`
