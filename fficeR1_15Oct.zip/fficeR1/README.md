# FF-ICE/R1 Filing Service

ICAO FF-ICE Release 1 compliant Filing Service implementation using Java Spring Boot.

## Overview

This is a standalone Filing Service that implements phases P1-P5 of the FF-ICE/R1 deployment roadmap:
- **P1**: Environment setup
- **P2**: Basic REST API endpoints
- **P3**: FIXM validation and business rules
- **P4**: Validation logging and ACK/NACK responses
- **P5**: SOAP/WSDL adapter for SWIM compatibility

## Technology Stack

- Java 17
- Spring Boot 3.3.2
- PostgreSQL 15
- Maven
- SOAP/WSDL (JAX-WS)

## Project Structure

```
filing-service/
├── src/main/java/com/vatm/ffice/
│   ├── FilingServiceApplication.java
│   ├── config/
│   │   └── WebServiceConfig.java
│   ├── controller/
│   │   └── FilingController.java
│   ├── model/
│   │   ├── FlightPlan.java
│   │   ├── ValidationLog.java
│   │   └── FilingResponse.java
│   ├── repository/
│   │   ├── FlightPlanRepository.java
│   │   └── ValidationLogRepository.java
│   ├── service/
│   │   └── FilingService.java
│   ├── utils/
│   │   ├── FixmValidator.java
│   │   └── FilingRuleEngine.java
│   └── ws/
│       └── FilingSoapEndpoint.java
├── src/main/resources/
│   ├── application.yml
│   └── wsdl/
│       └── filing.xsd
└── pom.xml
```

## Features

### REST API Endpoints

- `GET /health` - Health check endpoint
- `POST /api/v1/filing/submit` - Submit flight plan
- `GET /api/v1/filing/{gufi}` - Retrieve flight plan by GUFI

### SOAP/WSDL Endpoints

- `GET /ws/filing.wsdl` - WSDL definition
- `POST /ws` - SOAP endpoint for filing operations

### Validation

- FIXM XML format validation
- ICAO airport code validation (4 uppercase letters)
- Flight number format validation (XX000 or XX0000)
- ETD/ETA time validation
- Complete validation logging

## Prerequisites

- Java 17 or higher
- Maven 3.x
- PostgreSQL 15 or higher
- Ubuntu 22.04 (recommended) or Windows with WSL

## Quick Start

See DEPLOYMENT_GUIDE.md for detailed deployment instructions.

## API Examples

### REST API Example

```bash
curl -X POST http://localhost:8080/api/v1/filing/submit \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "VN123",
    "departure": "VVNB",
    "arrival": "VVTS",
    "etd": "2025-10-09T02:00:00",
    "eta": "2025-10-09T04:00:00",
    "fixmXml": "<FlightPlan>...</FlightPlan>"
  }'
```

### SOAP Example

```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:ffice="http://vatm.vn/ffice/wsdl">
   <soapenv:Body>
      <ffice:SubmitFilingRequest>
         <flightNumber>VN321</flightNumber>
         <departure>VVNB</departure>
         <arrival>VVTS</arrival>
         <etd>2025-10-09T02:00:00</etd>
         <eta>2025-10-09T04:00:00</eta>
         <fixmXml>&lt;FlightPlan&gt;...&lt;/FlightPlan&gt;</fixmXml>
      </ffice:SubmitFilingRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

## License

Internal use only - VATM (Vietnam Air Traffic Management)
