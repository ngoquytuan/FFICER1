# FF-ICE/R1 Filing Service - Deployment Guide

## Table of Contents
1. [Overview](#overview)
2. [What Was Implemented](#what-was-implemented)
3. [System Requirements](#system-requirements)
4. [Deployment on Ubuntu](#deployment-on-ubuntu)
5. [Testing the Service](#testing-the-service)
6. [Troubleshooting](#troubleshooting)

---

## Overview

This guide will help you deploy the FF-ICE/R1 Filing Service on an Ubuntu machine. The service implements phases P1-P5 of the ICAO FF-ICE Release 1 specification.

**What this service does:**
- Accepts flight plans via REST API and SOAP/WSDL
- Validates flight plans against FIXM schema and business rules
- Stores flight plans in PostgreSQL database
- Returns ACK/NACK responses according to ICAO standards
- Logs all validation attempts for auditing

---

## What Was Implemented

### Phase P1: Environment & Preparation
- Maven project structure with Spring Boot 3.3.2
- Java 17 configuration
- PostgreSQL database setup
- Application configuration

### Phase P2: Basic API
- REST endpoint: `POST /api/v1/filing/submit`
- REST endpoint: `GET /api/v1/filing/{gufi}`
- Health check endpoint: `GET /health`
- JSON request/response handling

### Phase P3: FIXM Parser & Validation
- FIXM XML validation
- Business rules engine with the following validations:
  - ICAO airport code format (4 uppercase letters)
  - Flight number format (2 letters + 3-4 digits)
  - ETD must be before ETA
  - FIXM XML basic structure validation
- Automatic GUFI generation (UUID format)

### Phase P4: Validation Logic & Logging
- Database table: `flight_plans` - stores accepted flight plans
- Database table: `validation_log` - logs all submission attempts
- ACK/NACK response format compliant with ICAO standards
- Detailed validation error messages

### Phase P5: SOAP/WSDL Adapter
- SOAP web service endpoint at `/ws`
- WSDL definition at `/ws/filing.wsdl`
- XSD schema for SOAP message validation
- Compatible with SWIM Yellow Profile

---

## System Requirements

### Hardware Requirements (Minimum)
- CPU: 2 cores
- RAM: 4 GB
- Disk: 20 GB free space

### Software Requirements
- Operating System: Ubuntu 22.04 LTS (recommended) or Ubuntu 20.04
- Java: OpenJDK 17
- Maven: 3.6+
- PostgreSQL: 15
- Docker & Docker Compose (optional, for containerized deployment)

---

## Deployment on Ubuntu

### Option 1: Native Deployment (Recommended for Production)

#### Step 1: Update System and Install Dependencies

```bash
# Update package lists
sudo apt update && sudo apt upgrade -y

# Install Java 17
sudo apt install openjdk-17-jdk -y

# Verify Java installation
java -version
# Expected output: openjdk version "17.0.x"

# Install Maven
sudo apt install maven -y

# Verify Maven installation
mvn -version
# Expected output: Apache Maven 3.x.x

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# Start and enable PostgreSQL
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Verify PostgreSQL is running
sudo systemctl status postgresql
```

#### Step 2: Configure PostgreSQL Database

```bash
# Switch to postgres user
sudo -u postgres psql

# In PostgreSQL prompt, run:
CREATE USER filing_user WITH PASSWORD 'filing_pass';
CREATE DATABASE filing_db OWNER filing_user;
GRANT ALL PRIVILEGES ON DATABASE filing_db TO filing_user;
\q

# Test database connection
psql -h localhost -U filing_user -d filing_db -W
# Enter password: filing_pass
# Type \q to exit
```

**Security Note:** In production, change the default password `filing_pass` to a strong password and update it in `src/main/resources/application.yml`.

#### Step 3: Deploy the Application

```bash
# Create application directory
sudo mkdir -p /opt/filing-service
cd /opt/filing-service

# Copy the source code to the server
# (Upload your fficeR1 folder to the server using scp, git, or other methods)

# Navigate to the project directory
cd /opt/filing-service

# Build the application
mvn clean package -DskipTests

# The JAR file will be created at: target/filing-service-1.0.0.jar
```

#### Step 4: Create Systemd Service (Optional but Recommended)

```bash
# Create service file
sudo nano /etc/systemd/system/filing-service.service
```

Paste the following content:

```ini
[Unit]
Description=FF-ICE Filing Service
After=postgresql.service

[Service]
Type=simple
User=filing-user
WorkingDirectory=/opt/filing-service
ExecStart=/usr/bin/java -jar /opt/filing-service/target/filing-service-1.0.0.jar
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Create the service user:

```bash
# Create user for running the service
sudo useradd -r -s /bin/false filing-user

# Set ownership
sudo chown -R filing-user:filing-user /opt/filing-service

# Reload systemd
sudo systemctl daemon-reload

# Enable and start the service
sudo systemctl enable filing-service
sudo systemctl start filing-service

# Check status
sudo systemctl status filing-service

# View logs
sudo journalctl -u filing-service -f
```

#### Step 5: Verify Deployment

```bash
# Check if the service is running
curl http://localhost:8080/health

# Expected response: "FF-ICE Filing Service is running"
```

---

### Option 2: Docker Deployment (Easier, Recommended for Testing)

#### Step 1: Install Docker and Docker Compose

```bash
# Install Docker
sudo apt update
sudo apt install docker.io -y
sudo systemctl enable docker
sudo systemctl start docker

# Install Docker Compose
sudo apt install docker-compose -y

# Verify installation
docker --version
docker-compose --version
```

#### Step 2: Deploy Using Docker Compose

```bash
# Navigate to project directory
cd /path/to/fficeR1

# Build and start services
sudo docker-compose up -d

# Check service status
sudo docker-compose ps

# View logs
sudo docker-compose logs -f filing-service

# The service will be available at http://localhost:8080
```

#### Docker Compose Commands

```bash
# Stop services
sudo docker-compose down

# Restart services
sudo docker-compose restart

# Rebuild after code changes
sudo docker-compose up -d --build

# View database logs
sudo docker-compose logs -f postgres
```

---

## Testing the Service

### 1. Health Check

```bash
curl http://localhost:8080/health
```

Expected response: `FF-ICE Filing Service is running`

### 2. Test REST API - Submit Flight Plan

```bash
curl -X POST http://localhost:8080/api/v1/filing/submit \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "VN123",
    "departure": "VVNB",
    "arrival": "VVTS",
    "etd": "2025-10-15T02:00:00",
    "eta": "2025-10-15T04:00:00",
    "fixmXml": "<FlightPlan xmlns=\"http://www.fixm.aero/schema\">Sample FIXM content</FlightPlan>"
  }'
```

Expected response (ACCEPTED):
```json
{
  "gufi": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "status": "ACCEPTED",
  "message": "Flight plan filed successfully",
  "timestamp": "2025-10-15T..."
}
```

### 3. Test REST API - Retrieve Flight Plan

```bash
# Replace {gufi} with the GUFI from the previous response
curl http://localhost:8080/api/v1/filing/{gufi}
```

### 4. Test SOAP API - View WSDL

```bash
curl http://localhost:8080/ws/filing.wsdl
```

This should return the WSDL XML definition.

### 5. Test SOAP API - Submit via SOAP

Save this as `soap-request.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:ffice="http://vatm.vn/ffice/wsdl">
   <soapenv:Body>
      <ffice:SubmitFilingRequest>
         <ffice:flightNumber>VN321</ffice:flightNumber>
         <ffice:departure>VVNB</ffice:departure>
         <ffice:arrival>VVTS</ffice:arrival>
         <ffice:etd>2025-10-15T02:00:00</ffice:etd>
         <ffice:eta>2025-10-15T04:00:00</ffice:eta>
         <ffice:fixmXml>&lt;FlightPlan&gt;Test&lt;/FlightPlan&gt;</ffice:fixmXml>
      </ffice:SubmitFilingRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

Send the SOAP request:

```bash
curl -X POST http://localhost:8080/ws \
  -H "Content-Type: text/xml" \
  -d @soap-request.xml
```

### 6. Test Validation - Invalid Airport Code

```bash
curl -X POST http://localhost:8080/api/v1/filing/submit \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "VN123",
    "departure": "HN",
    "arrival": "VVTS",
    "etd": "2025-10-15T02:00:00",
    "eta": "2025-10-15T04:00:00",
    "fixmXml": "<FlightPlan>Test</FlightPlan>"
  }'
```

Expected response (REJECTED):
```json
{
  "status": "REJECTED",
  "message": "Invalid departure ICAO airport code. Must be 4 uppercase letters.",
  "timestamp": "..."
}
```

### 7. Verify Database

```bash
# Connect to database
psql -h localhost -U filing_user -d filing_db -W

# View flight plans
SELECT gufi, flight_number, departure, arrival, status, created_at FROM flight_plans;

# View validation logs
SELECT flight_number, validation_status, validation_message, received_at FROM validation_log;

# Exit
\q
```

---

## Troubleshooting

### Service Won't Start

**Problem:** Service fails to start

**Solutions:**
1. Check Java version: `java -version` (must be 17+)
2. Check if port 8080 is already in use:
   ```bash
   sudo netstat -tulpn | grep 8080
   # or
   sudo lsof -i :8080
   ```
3. Kill process using port 8080:
   ```bash
   sudo kill -9 <PID>
   ```
4. Check application logs:
   ```bash
   sudo journalctl -u filing-service -n 100
   ```

### Database Connection Failed

**Problem:** Cannot connect to PostgreSQL

**Solutions:**
1. Check PostgreSQL is running:
   ```bash
   sudo systemctl status postgresql
   ```
2. Verify database and user exist:
   ```bash
   sudo -u postgres psql -c "\l" | grep filing_db
   sudo -u postgres psql -c "\du" | grep filing_user
   ```
3. Test connection manually:
   ```bash
   psql -h localhost -U filing_user -d filing_db -W
   ```
4. Check PostgreSQL logs:
   ```bash
   sudo tail -f /var/log/postgresql/postgresql-15-main.log
   ```

### Maven Build Fails

**Problem:** Build errors when running `mvn clean package`

**Solutions:**
1. Clean Maven cache:
   ```bash
   mvn clean
   rm -rf ~/.m2/repository
   mvn package
   ```
2. Check Maven version:
   ```bash
   mvn -version
   ```
3. Ensure internet connection is available (Maven needs to download dependencies)

### Docker Issues

**Problem:** Docker containers not starting

**Solutions:**
1. Check Docker service:
   ```bash
   sudo systemctl status docker
   ```
2. View container logs:
   ```bash
   sudo docker-compose logs
   ```
3. Remove and recreate containers:
   ```bash
   sudo docker-compose down -v
   sudo docker-compose up -d
   ```

### Port Already in Use

**Problem:** Port 8080 or 5432 is already in use

**Solutions:**
1. Change application port in `application.yml`:
   ```yaml
   server:
     port: 8081  # Change to another port
   ```
2. Or kill the process using the port:
   ```bash
   sudo lsof -ti:8080 | xargs sudo kill -9
   ```

---

## Configuration Reference

### Application Configuration

File: `src/main/resources/application.yml`

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/filing_db
    username: filing_user
    password: filing_pass  # Change in production!
  jpa:
    hibernate:
      ddl-auto: update  # Use 'validate' in production
    show-sql: true  # Set to false in production

server:
  port: 8080
```

### Database Configuration

Default credentials (CHANGE IN PRODUCTION):
- Database: `filing_db`
- Username: `filing_user`
- Password: `filing_pass`
- Host: `localhost`
- Port: `5432`

---

## Security Recommendations (Not Yet Implemented)

The current implementation (P1-P5) does NOT include security features. For production deployment, you should implement Phase P6 (Security Layer):

1. **HTTPS/TLS**: Enable SSL certificates
2. **Authentication**: Add JWT tokens or OAuth2
3. **mTLS**: Mutual TLS for SOAP endpoints
4. **Firewall**: Configure firewall rules
5. **Database Encryption**: Enable PostgreSQL SSL
6. **Password Management**: Use secrets management tools
7. **Rate Limiting**: Prevent abuse
8. **Audit Logging**: Enhanced logging for security events

---

## Next Steps

After successful deployment:

1. **Monitor the service**: Set up monitoring tools (Prometheus, Grafana)
2. **Configure backups**: Set up PostgreSQL backup schedules
3. **Implement P6 (Security)**: Add authentication and encryption
4. **Load testing**: Test with multiple concurrent requests
5. **FIXM Schema**: Add actual FIXM 4.2.0 XSD validation
6. **Integration**: Connect to SWIM Gateway or Planning Service

---

## Support & Documentation

- Project documentation: See `README.md`
- ICAO FF-ICE documentation: `FFICE_deploy2.md`
- API testing: Use Postman or SoapUI
- Database schema: Auto-generated by Hibernate

---

## Summary of Deployed Components

| Component | Status | Endpoint/Location |
|-----------|--------|------------------|
| REST API | ✅ Deployed | http://localhost:8080/api/v1/filing |
| SOAP API | ✅ Deployed | http://localhost:8080/ws |
| WSDL | ✅ Available | http://localhost:8080/ws/filing.wsdl |
| Health Check | ✅ Working | http://localhost:8080/health |
| PostgreSQL | ✅ Running | localhost:5432 |
| FIXM Validation | ✅ Basic validation | In code |
| Business Rules | ✅ Implemented | 4 rules active |
| Validation Logging | ✅ Active | Database table: validation_log |

---

**Deployment completed successfully!**

The FF-ICE/R1 Filing Service is now ready for testing and integration.
