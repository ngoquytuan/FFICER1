package com.vatm.ffice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.vatm.ffice.model.FlightPlan;

@Repository
public interface FlightPlanRepository extends JpaRepository<FlightPlan, Long> {
    FlightPlan findByGufi(String gufi);
}
