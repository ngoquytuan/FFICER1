package com.vatm.ffice.utils;

import com.vatm.ffice.model.FlightPlan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

@Component
public class FilingRuleEngine {

    @Autowired
    private FixmValidator fixmValidator;

    /**
     * Validates business rules for flight plan filing
     * Returns "OK" if all rules pass, otherwise returns error message
     */
    public String validateBusinessRules(FlightPlan plan) {

        // Rule 1: ICAO airport code (4 uppercase letters)
        if (plan.getDeparture() == null || !Pattern.matches("^[A-Z]{4}$", plan.getDeparture())) {
            return "Invalid departure ICAO airport code. Must be 4 uppercase letters.";
        }

        if (plan.getArrival() == null || !Pattern.matches("^[A-Z]{4}$", plan.getArrival())) {
            return "Invalid arrival ICAO airport code. Must be 4 uppercase letters.";
        }

        // Rule 2: Flight number (2 letters + 3-4 digits)
        if (plan.getFlightNumber() == null || !Pattern.matches("^[A-Z]{2}\\d{3,4}$", plan.getFlightNumber())) {
            return "Invalid flight number format. Expected format: XX000 or XX0000 (e.g., VN123).";
        }

        // Rule 3: ETD < ETA
        if (plan.getEtd() != null && plan.getEta() != null) {
            if (!plan.getEtd().isBefore(plan.getEta())) {
                return "ETD (Estimated Time of Departure) must be before ETA (Estimated Time of Arrival).";
            }
        }

        // Rule 4: FIXM validation
        if (plan.getFixmXml() == null || plan.getFixmXml().trim().isEmpty()) {
            return "FIXM XML is required.";
        }

        if (!fixmValidator.validateXml(plan.getFixmXml())) {
            return "Invalid FIXM XML format.";
        }

        return "OK";
    }
}
