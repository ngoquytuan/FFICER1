package com.vatm.ffice.ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import com.vatm.ffice.service.FilingService;
import com.vatm.ffice.model.FlightPlan;
import com.vatm.ffice.model.FilingResponse;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Endpoint
public class FilingSoapEndpoint {

    private static final String NAMESPACE_URI = "http://vatm.vn/ffice/wsdl";

    @Autowired
    private FilingService filingService;

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "SubmitFilingRequest")
    @ResponsePayload
    public Element submitFiling(@RequestPayload Element request) throws Exception {
        // Parse request
        String flightNumber = getElementValue(request, "flightNumber");
        String departure = getElementValue(request, "departure");
        String arrival = getElementValue(request, "arrival");
        String etdStr = getElementValue(request, "etd");
        String etaStr = getElementValue(request, "eta");
        String fixmXml = getElementValue(request, "fixmXml");

        FlightPlan plan = new FlightPlan();
        plan.setFlightNumber(flightNumber);
        plan.setDeparture(departure);
        plan.setArrival(arrival);
        plan.setEtd(LocalDateTime.parse(etdStr, DateTimeFormatter.ISO_DATE_TIME));
        plan.setEta(LocalDateTime.parse(etaStr, DateTimeFormatter.ISO_DATE_TIME));
        plan.setFixmXml(fixmXml);

        FilingResponse response = filingService.submit(plan);

        // Build response
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.newDocument();

        Element responseElement = doc.createElementNS(NAMESPACE_URI, "SubmitFilingResponse");

        if (response.getGufi() != null) {
            Element gufiElement = doc.createElement("gufi");
            gufiElement.setTextContent(response.getGufi());
            responseElement.appendChild(gufiElement);
        }

        Element statusElement = doc.createElement("status");
        statusElement.setTextContent(response.getStatus());
        responseElement.appendChild(statusElement);

        Element messageElement = doc.createElement("message");
        messageElement.setTextContent(response.getMessage());
        responseElement.appendChild(messageElement);

        Element timestampElement = doc.createElement("timestamp");
        timestampElement.setTextContent(response.getTimestamp().format(DateTimeFormatter.ISO_DATE_TIME));
        responseElement.appendChild(timestampElement);

        return responseElement;
    }

    private String getElementValue(Element parent, String tagName) {
        org.w3c.dom.NodeList nodeList = parent.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return null;
    }
}
