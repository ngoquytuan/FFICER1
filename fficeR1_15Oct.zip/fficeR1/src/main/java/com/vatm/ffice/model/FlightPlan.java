package com.vatm.ffice.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "flight_plans")
public class FlightPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String gufi;
    private String flightNumber;
    private String departure;
    private String arrival;
    private LocalDateTime etd;
    private LocalDateTime eta;
    private String status;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String fixmXml;

    private LocalDateTime createdAt = LocalDateTime.now();

    @PrePersist
    public void generateGufi() {
        if (this.gufi == null) {
            this.gufi = UUID.randomUUID().toString();
        }
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGufi() {
        return gufi;
    }

    public void setGufi(String gufi) {
        this.gufi = gufi;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getDeparture() {
        return departure;
    }

    public void setDeparture(String departure) {
        this.departure = departure;
    }

    public String getArrival() {
        return arrival;
    }

    public void setArrival(String arrival) {
        this.arrival = arrival;
    }

    public LocalDateTime getEtd() {
        return etd;
    }

    public void setEtd(LocalDateTime etd) {
        this.etd = etd;
    }

    public LocalDateTime getEta() {
        return eta;
    }

    public void setEta(LocalDateTime eta) {
        this.eta = eta;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFixmXml() {
        return fixmXml;
    }

    public void setFixmXml(String fixmXml) {
        this.fixmXml = fixmXml;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
