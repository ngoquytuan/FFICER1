package com.vatm.ffice.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.vatm.ffice.repository.*;
import com.vatm.ffice.model.*;
import com.vatm.ffice.utils.FilingRuleEngine;
import com.vatm.ffice.utils.FixmValidator;

@Service
public class FilingService {

    @Autowired
    private FlightPlanRepository flightRepo;

    @Autowired
    private ValidationLogRepository logRepo;

    @Autowired
    private FixmValidator fixmValidator;

    @Autowired
    private FilingRuleEngine ruleEngine;

    public FilingResponse submit(FlightPlan plan) {

        boolean fixmValid = fixmValidator.validateXml(plan.getFixmXml());
        String ruleResult = ruleEngine.validateBusinessRules(plan);

        ValidationLog log = new ValidationLog();
        log.setFlightNumber(plan.getFlightNumber());
        log.setRawRequest(plan.getFixmXml());
        log.setFixmIsValid(fixmValid);
        log.setBusinessIsValid(ruleResult.equals("OK"));

        if (!fixmValid) {
            log.setValidationStatus("REJECTED");
            log.setValidationMessage("Invalid FIXM XML");
            logRepo.save(log);
            return FilingResponse.nack("Invalid FIXM XML");
        }

        if (!ruleResult.equals("OK")) {
            log.setValidationStatus("REJECTED");
            log.setValidationMessage(ruleResult);
            logRepo.save(log);
            return FilingResponse.nack(ruleResult);
        }

        // If all validation passes
        plan.setStatus("FILED");
        FlightPlan saved = flightRepo.save(plan);

        log.setGufi(saved.getGufi());
        log.setValidationStatus("ACCEPTED");
        log.setValidationMessage("Flight plan accepted");
        logRepo.save(log);

        return FilingResponse.ack(saved.getGufi(), "Flight plan filed successfully");
    }

    public FlightPlan findByGufi(String gufi) {
        return flightRepo.findByGufi(gufi);
    }
}
