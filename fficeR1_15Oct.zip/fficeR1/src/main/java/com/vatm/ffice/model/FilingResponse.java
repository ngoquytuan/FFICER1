package com.vatm.ffice.model;

import java.time.LocalDateTime;

public class FilingResponse {
    private String gufi;
    private String status;
    private String message;
    private LocalDateTime timestamp;

    public FilingResponse(String gufi, String status, String message) {
        this.gufi = gufi;
        this.status = status;
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    public static FilingResponse ack(String gufi, String msg) {
        return new FilingResponse(gufi, "ACCEPTED", msg);
    }

    public static FilingResponse nack(String msg) {
        return new FilingResponse(null, "REJECTED", msg);
    }

    // Getters and Setters
    public String getGufi() {
        return gufi;
    }

    public void setGufi(String gufi) {
        this.gufi = gufi;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
