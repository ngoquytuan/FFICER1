package com.vatm.ffice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.vatm.ffice.service.FilingService;
import com.vatm.ffice.model.FlightPlan;
import com.vatm.ffice.model.FilingResponse;

@RestController
@RequestMapping("/api/v1/filing")
public class FilingController {

    @Autowired
    private FilingService filingService;

    @PostMapping("/submit")
    public ResponseEntity<FilingResponse> submit(@RequestBody FlightPlan plan) {
        FilingResponse resp = filingService.submit(plan);
        if (resp.getStatus().equals("REJECTED")) {
            return ResponseEntity.badRequest().body(resp);
        }
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/{gufi}")
    public ResponseEntity<FlightPlan> getByGufi(@PathVariable String gufi) {
        FlightPlan plan = filingService.findByGufi(gufi);
        if (plan == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(plan);
    }
}
