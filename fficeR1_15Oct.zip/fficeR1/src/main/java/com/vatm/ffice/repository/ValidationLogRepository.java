package com.vatm.ffice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.vatm.ffice.model.ValidationLog;

@Repository
public interface ValidationLogRepository extends JpaRepository<ValidationLog, Long> {
}
