package com.vatm.ffice.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "validation_log")
public class ValidationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String gufi;
    private String flightNumber;
    private String validationStatus;
    private String validationMessage;
    private Boolean fixmIsValid;
    private Boolean businessIsValid;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String rawRequest;

    private LocalDateTime receivedAt = LocalDateTime.now();

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGufi() {
        return gufi;
    }

    public void setGufi(String gufi) {
        this.gufi = gufi;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getValidationStatus() {
        return validationStatus;
    }

    public void setValidationStatus(String validationStatus) {
        this.validationStatus = validationStatus;
    }

    public String getValidationMessage() {
        return validationMessage;
    }

    public void setValidationMessage(String validationMessage) {
        this.validationMessage = validationMessage;
    }

    public Boolean getFixmIsValid() {
        return fixmIsValid;
    }

    public void setFixmIsValid(Boolean fixmIsValid) {
        this.fixmIsValid = fixmIsValid;
    }

    public Boolean getBusinessIsValid() {
        return businessIsValid;
    }

    public void setBusinessIsValid(Boolean businessIsValid) {
        this.businessIsValid = businessIsValid;
    }

    public String getRawRequest() {
        return rawRequest;
    }

    public void setRawRequest(String rawRequest) {
        this.rawRequest = rawRequest;
    }

    public LocalDateTime getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(LocalDateTime receivedAt) {
        this.receivedAt = receivedAt;
    }
}
