const express = require('express');
const mqtt = require('mqtt');
const app = express();
const PORT = process.env.PORT || 8087;

const mqttClient = mqtt.connect('mqtt://localhost:1883');

app.use(express.json());

let subscriptions = [];

mqttClient.on('connect', () => {
  console.log('✅ Connected to MQTT broker');
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    service: 'swim-subscription',
    status: 'ok',
    mqttConnected: mqttClient.connected
  });
});

// Subscribe to topic
app.post('/subscription/subscribe', (req, res) => {
  const { clientId, topic } = req.body;

  if (!clientId || !topic) {
    return res.status(400).json({ error: 'Missing clientId or topic' });
  }

  mqttClient.subscribe(topic, (err) => {
    if (err) {
      return res.status(500).json({ error: 'Subscription failed' });
    }

    subscriptions.push({ clientId, topic, subscribedAt: new Date() });
    console.log(`📡 ${clientId} subscribed to ${topic}`);

    res.json({
      status: 'subscribed',
      clientId,
      topic
    });
  });
});

// Publish message
app.post('/subscription/publish', (req, res) => {
  const { topic, message } = req.body;

  if (!topic || !message) {
    return res.status(400).json({ error: 'Missing topic or message' });
  }

  mqttClient.publish(topic, JSON.stringify(message), (err) => {
    if (err) {
      return res.status(500).json({ error: 'Publish failed' });
    }

    console.log(`📤 Published to ${topic}`);
    res.json({ status: 'published', topic });
  });
});

// List subscriptions
app.get('/subscription/list', (req, res) => {
  res.json({
    total: subscriptions.length,
    subscriptions
  });
});

// MQTT message handler
mqttClient.on('message', (topic, message) => {
  console.log(`📥 Received on ${topic}: ${message.toString()}`);
  // Can forward to WebSocket or webhook
});

app.listen(PORT, () => {
  console.log(`🔔 SWIM Subscription Service running on port ${PORT}`);
  console.log(`   MQTT Broker: mqtt://localhost:1883`);
});
