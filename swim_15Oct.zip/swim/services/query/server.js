const express = require('express');
const app = express();
const PORT = process.env.PORT || 8081;

app.use(express.json());

// Mock flight database
const flights = [
  {
    gufi: 'VN123-20251015-001',
    flightNumber: 'VN123',
    departure: 'VVNB',
    arrival: 'VVTS',
    departureTime: '2025-10-15T08:00:00Z',
    arrivalTime: '2025-10-15T10:15:00Z',
    status: 'FILED',
    aircraftType: 'A321'
  },
  {
    gufi: 'VN456-20251015-002',
    flightNumber: 'VN456',
    departure: 'VVTS',
    arrival: 'VVDN',
    departureTime: '2025-10-15T14:30:00Z',
    arrivalTime: '2025-10-15T16:00:00Z',
    status: 'AIRBORNE',
    aircraftType: 'B787'
  }
];

// Health check
app.get('/health', (req, res) => {
  res.json({ service: 'ff-ice-query', status: 'ok' });
});

// Query all flights
app.get('/flight/query', (req, res) => {
  const { flightNumber, departure, arrival } = req.query;

  let results = flights;

  if (flightNumber) {
    results = results.filter(f => f.flightNumber === flightNumber);
  }
  if (departure) {
    results = results.filter(f => f.departure === departure);
  }
  if (arrival) {
    results = results.filter(f => f.arrival === arrival);
  }

  res.json({
    count: results.length,
    flights: results
  });
});

// Query by GUFI
app.get('/flight/query/:gufi', (req, res) => {
  const flight = flights.find(f => f.gufi === req.params.gufi);

  if (flight) {
    res.json(flight);
  } else {
    res.status(404).json({ error: 'Flight not found' });
  }
});

app.listen(PORT, () => {
  console.log(`🛫 FF-ICE Query Service running on port ${PORT}`);
});
