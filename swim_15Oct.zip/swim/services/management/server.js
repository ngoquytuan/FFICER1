const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 8086;

app.use(express.json());
app.use(express.static('public'));

// Health check
app.get('/health', (req, res) => {
  res.json({ service: 'swim-management', status: 'ok' });
});

// Dashboard overview
app.get('/management/overview', async (req, res) => {
  try {
    const [registry, monitoring] = await Promise.all([
      axios.get('http://localhost:8090/registry/services'),
      axios.get('http://localhost:8085/monitoring/health-check')
    ]);

    res.json({
      timestamp: new Date().toISOString(),
      totalServices: registry.data.total,
      services: registry.data.services,
      health: monitoring.data.services
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch overview' });
  }
});

// Service control
app.post('/management/service/:id/restart', async (req, res) => {
  // Mock restart - in production would call PM2 API
  res.json({
    status: 'restarted',
    serviceId: req.params.id,
    message: 'Service restart initiated'
  });
});

// Configuration management
app.get('/management/config', (req, res) => {
  res.json({
    environment: 'development',
    version: '1.0.0',
    features: {
      authentication: true,
      monitoring: true,
      subscription: true
    }
  });
});

// Logs endpoint
app.get('/management/logs/:service', async (req, res) => {
  res.json({
    service: req.params.service,
    logs: [
      { timestamp: new Date().toISOString(), level: 'info', message: 'Service started' },
      { timestamp: new Date().toISOString(), level: 'info', message: 'Processing request' }
    ]
  });
});

app.listen(PORT, () => {
  console.log(`🧰 SWIM Management Service running on port ${PORT}`);
  console.log(`   Dashboard: http://localhost:${PORT}`);
});
