const express = require('express');
const app = express();
const PORT = process.env.PORT || 8082;

app.use(express.json());

let filedFlights = [];
let gufiCounter = 1;

// Health check
app.get('/health', (req, res) => {
  res.json({ service: 'ff-ice-filing', status: 'ok' });
});

// Submit flight plan
app.post('/filing/submit', (req, res) => {
  const { flightNumber, departure, arrival, departureTime, aircraftType } = req.body;

  if (!flightNumber || !departure || !arrival) {
    return res.status(400).json({
      error: 'Missing required fields'
    });
  }

  const gufi = `${flightNumber}-${new Date().toISOString().split('T')[0]}-${String(gufiCounter++).padStart(3, '0')}`;

  const flight = {
    gufi,
    flightNumber,
    departure,
    arrival,
    departureTime: departureTime || new Date().toISOString(),
    aircraftType: aircraftType || 'UNKNOWN',
    status: 'FILED',
    filedAt: new Date().toISOString()
  };

  filedFlights.push(flight);

  console.log(`✈️ Flight plan filed: ${gufi}`);

  res.status(201).json({
    status: 'accepted',
    gufi,
    flight
  });
});

// Get all filed flights
app.get('/filing/list', (req, res) => {
  res.json({
    count: filedFlights.length,
    flights: filedFlights
  });
});

app.listen(PORT, () => {
  console.log(`📝 FF-ICE Filing Service running on port ${PORT}`);
});
