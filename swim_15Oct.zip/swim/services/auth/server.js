const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();
const PORT = process.env.PORT || 8083;

const SECRET_KEY = 'SWIM-SECRET-2025-CHANGE-IN-PRODUCTION';
const users = {
  'airline1': { password: 'pass123', role: 'operator' },
  'atm1': { password: 'pass456', role: 'atm' },
  'admin': { password: 'admin123', role: 'admin' }
};

app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ service: 'swim-auth', status: 'ok' });
});

// Login endpoint
app.post('/auth/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Missing credentials' });
  }

  const user = users[username];
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign(
    {
      username,
      role: user.role,
      iss: 'swim-mini',
      exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24) // 24h
    },
    SECRET_KEY
  );

  console.log(`✅ Login successful: ${username} (${user.role})`);

  res.json({
    status: 'success',
    token,
    expiresIn: '24h',
    user: { username, role: user.role }
  });
});

// Verify token endpoint
app.post('/auth/verify', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    res.json({
      valid: true,
      user: decoded
    });
  } catch (err) {
    res.status(401).json({
      valid: false,
      error: 'Invalid or expired token'
    });
  }
});

// Refresh token
app.post('/auth/refresh', (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');

  try {
    const decoded = jwt.verify(token, SECRET_KEY, { ignoreExpiration: true });

    const newToken = jwt.sign(
      {
        username: decoded.username,
        role: decoded.role,
        iss: 'swim-mini',
        exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24)
      },
      SECRET_KEY
    );

    res.json({ token: newToken });
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

app.listen(PORT, () => {
  console.log(`🔐 SWIM Auth Service running on port ${PORT}`);
});
