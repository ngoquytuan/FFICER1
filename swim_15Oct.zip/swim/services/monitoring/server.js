const express = require('express');
const promClient = require('prom-client');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 8085;

// Prometheus metrics
const register = new promClient.Registry();
promClient.collectDefaultMetrics({ register });

// Custom metrics
const httpRequestDuration = new promClient.Histogram({
  name: 'swim_http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status'],
  registers: [register]
});

const serviceHealthGauge = new promClient.Gauge({
  name: 'swim_service_health',
  help: 'Health status of SWIM services (1=healthy, 0=unhealthy)',
  labelNames: ['service_name', 'service_type'],
  registers: [register]
});

const messageCounter = new promClient.Counter({
  name: 'swim_messages_total',
  help: 'Total number of SWIM messages processed',
  labelNames: ['service', 'type'],
  registers: [register]
});

app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ service: 'swim-monitoring', status: 'ok' });
});

// Prometheus metrics endpoint
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(await register.metrics());
});

// Record message
app.post('/monitoring/record', (req, res) => {
  const { service, type, duration, status } = req.body;

  if (duration) {
    httpRequestDuration.observe(
      { method: 'POST', route: '/swim', status: status || 200 },
      duration
    );
  }

  if (service && type) {
    messageCounter.inc({ service, type });
  }

  res.json({ status: 'recorded' });
});

// Check all services health
app.get('/monitoring/health-check', async (req, res) => {
  const services = [
    { name: 'registry', url: 'http://localhost:8090/health', type: 'core' },
    { name: 'auth', url: 'http://localhost:8083/health', type: 'core' },
    { name: 'discovery', url: 'http://localhost:8084/health', type: 'core' },
    { name: 'query', url: 'http://localhost:8081/health', type: 'ff-ice' },
    { name: 'filing', url: 'http://localhost:8082/health', type: 'ff-ice' }
  ];

  const results = await Promise.all(
    services.map(async (svc) => {
      try {
        await axios.get(svc.url, { timeout: 2000 });
        serviceHealthGauge.set({ service_name: svc.name, service_type: svc.type }, 1);
        return { ...svc, status: 'healthy' };
      } catch {
        serviceHealthGauge.set({ service_name: svc.name, service_type: svc.type }, 0);
        return { ...svc, status: 'unhealthy' };
      }
    })
  );

  res.json({
    timestamp: new Date().toISOString(),
    services: results
  });
});

// Statistics
app.get('/monitoring/stats', (req, res) => {
  res.json({
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    timestamp: new Date().toISOString()
  });
});

app.listen(PORT, () => {
  console.log(`📊 SWIM Monitoring Service running on port ${PORT}`);
  console.log(`   Metrics: http://localhost:${PORT}/metrics`);

  // Periodic health check
  setInterval(async () => {
    await axios.get(`http://localhost:${PORT}/monitoring/health-check`).catch(() => {});
  }, 30000); // Every 30 seconds
});
