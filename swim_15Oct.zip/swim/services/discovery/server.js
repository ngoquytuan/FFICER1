const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 8084;

const REGISTRY_URL = 'http://localhost:8090';
let discoveryCache = {};
let lastUpdate = null;

app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ service: 'swim-discovery', status: 'ok' });
});

// Auto-discover services by type
app.get('/discovery/find/:type', async (req, res) => {
  const serviceType = req.params.type;

  try {
    // Check cache first (TTL: 30 seconds)
    const now = Date.now();
    if (discoveryCache[serviceType] &&
        lastUpdate &&
        (now - lastUpdate < 30000)) {
      console.log(`📦 Cache hit for ${serviceType}`);
      return res.json({
        source: 'cache',
        services: discoveryCache[serviceType]
      });
    }

    // Query registry
    const response = await axios.get(`${REGISTRY_URL}/registry/find/${serviceType}`);
    const services = response.data.services || [];

    // Health check all services
    const healthChecks = await Promise.all(
      services.map(async (service) => {
        try {
          const healthUrl = service.url.replace(/\/[^\/]*$/, '/health');
          await axios.get(healthUrl, { timeout: 2000 });
          return { ...service, health: 'healthy' };
        } catch {
          return { ...service, health: 'unhealthy' };
        }
      })
    );

    // Update cache
    discoveryCache[serviceType] = healthChecks;
    lastUpdate = now;

    console.log(`🔍 Discovered ${healthChecks.length} services for ${serviceType}`);

    res.json({
      source: 'registry',
      count: healthChecks.length,
      services: healthChecks
    });

  } catch (error) {
    console.error('Discovery error:', error.message);
    res.status(500).json({
      error: 'Discovery failed',
      message: error.message
    });
  }
});

// Get best service (load balancing)
app.get('/discovery/best/:type', async (req, res) => {
  try {
    const response = await axios.get(`http://localhost:${PORT}/discovery/find/${req.params.type}`);
    const services = response.data.services.filter(s => s.health === 'healthy');

    if (services.length === 0) {
      return res.status(404).json({ error: 'No healthy service found' });
    }

    // Simple round-robin
    const selected = services[Math.floor(Math.random() * services.length)];

    res.json({
      service: selected,
      alternatives: services.length - 1
    });

  } catch (error) {
    res.status(500).json({ error: 'Discovery failed' });
  }
});

// Clear cache
app.post('/discovery/refresh', (req, res) => {
  discoveryCache = {};
  lastUpdate = null;
  console.log('🗑️ Discovery cache cleared');
  res.json({ status: 'cache cleared' });
});

app.listen(PORT, () => {
  console.log(`🧭 SWIM Discovery Service running on port ${PORT}`);
});
