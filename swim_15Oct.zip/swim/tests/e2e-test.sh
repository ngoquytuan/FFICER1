#!/bin/bash

echo "🧪 SWIM Mini - Complete E2E Test"
echo ""

# 1. Authentication
echo "1️⃣ Authenticating..."
TOKEN=$(curl -s -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}' \
  | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
    echo "   ❌ Authentication failed"
    exit 1
fi
echo "   ✅ Token obtained"

# 2. Service Discovery
echo "2️⃣ Discovering services..."
FILING_URL=$(curl -s http://localhost:8084/discovery/best/ff-ice-filing | grep -o '"url":"[^"]*' | cut -d'"' -f4)

if [ -z "$FILING_URL" ]; then
    echo "   ❌ Discovery failed"
    exit 1
fi
echo "   ✅ Filing service: $FILING_URL"

# 3. File Flight Plan
echo "3️⃣ Filing flight plan..."
FLIGHT_DATA=$(date +%Y-%m-%dT%H:%M:%SZ)
GUFI=$(curl -s -X POST "$FILING_URL" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"flightNumber\": \"TEST001\",
    \"departure\": \"VVNB\",
    \"arrival\": \"VVTS\",
    \"departureTime\": \"$FLIGHT_DATA\",
    \"aircraftType\": \"B787\"
  }" | grep -o '"gufi":"[^"]*' | cut -d'"' -f4)

if [ -z "$GUFI" ]; then
    echo "   ❌ Filing failed"
    exit 1
fi
echo "   ✅ GUFI: $GUFI"

# 4. Publish notification
echo "4️⃣ Publishing notification..."
PUBLISH_RESULT=$(curl -s -X POST http://localhost:8087/subscription/publish \
  -H "Content-Type: application/json" \
  -d "{
    \"topic\": \"swim/flight/filed\",
    \"message\": {
      \"gufi\": \"$GUFI\",
      \"status\": \"FILED\",
      \"timestamp\": \"$FLIGHT_DATA\"
    }
  }" | grep -o '"status":"[^"]*' | cut -d'"' -f4)

if [ "$PUBLISH_RESULT" != "published" ]; then
    echo "   ❌ Publish failed"
else
    echo "   ✅ Notification published"
fi

# 5. Query filed flight
echo "5️⃣ Querying filed flights..."
QUERY_URL=$(curl -s http://localhost:8084/discovery/best/ff-ice-query | grep -o '"url":"[^"]*' | cut -d'"' -f4)
QUERY_RESULT=$(curl -s "$QUERY_URL" -H "Authorization: Bearer $TOKEN")

if [ -z "$QUERY_RESULT" ]; then
    echo "   ❌ Query failed"
else
    echo "   ✅ Query successful"
fi

# 6. Check monitoring
echo "6️⃣ Checking system health..."
HEALTH_DATA=$(curl -s http://localhost:8085/monitoring/health-check)
TOTAL=$(echo "$HEALTH_DATA" | grep -o '"name":"[^"]*' | wc -l)
HEALTHY=$(echo "$HEALTH_DATA" | grep -c '"status":"healthy"')

echo "   ✅ Health: $HEALTHY/$TOTAL services healthy"

echo ""
echo "✅ E2E Test Complete!"
