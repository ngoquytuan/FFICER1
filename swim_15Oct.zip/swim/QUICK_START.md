# SWIM Mini - Quick Start Guide

## For Ubuntu Deployment

### 1. Prerequisites (5 minutes)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install tools
sudo npm install -g pm2 node-red
sudo apt install -y mosquitto mosquitto-clients git
```

### 2. Get the Code (2 minutes)

```bash
# Option A: From your Windows machine
cd D:\Projects
tar -czf swim.tar.gz swim
scp swim.tar.gz user@ubuntu-server:/home/user/

# On Ubuntu
cd ~
tar -xzf swim.tar.gz
mv swim swim-mini
cd swim-mini

# Option B: Using Git
git clone <repository-url> swim-mini
cd swim-mini
```

### 3. Install Dependencies (5 minutes)

```bash
cd ~/swim-mini

# Install for all services
for dir in registry services/*/; do
  echo "Installing $dir"
  cd ~/swim-mini/$dir
  npm install
done

cd ~/swim-mini
```

### 4. Make Scripts Executable (1 minute)

```bash
chmod +x start-all.sh
chmod +x register-services.sh
chmod +x tests/e2e-test.sh
```

### 5. Start All Services (1 minute)

```bash
./start-all.sh
```

### 6. Verify Everything Works (2 minutes)

```bash
# Check services are running
pm2 list

# Run E2E test
./tests/e2e-test.sh

# Check health
curl http://localhost:8085/monitoring/health-check | jq
```

### 7. Access the System

Open your browser:
- **Management Dashboard**: http://your-server-ip:8086
- **Node-RED**: http://your-server-ip:1880
- **Service Registry**: http://your-server-ip:8090/registry/services

## Quick Commands

```bash
# View all logs
pm2 logs

# Restart all services
pm2 restart all

# Stop all services
pm2 stop all

# Check service health
curl http://localhost:8085/monitoring/health-check

# Test authentication
curl -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}'

# Query flights
TOKEN="<your-jwt-token>"
curl http://localhost:8081/flight/query \
  -H "Authorization: Bearer $TOKEN"
```

## Default Credentials

- **airline1** / pass123
- **atm1** / pass456
- **admin** / admin123

## Need Help?

- Full deployment guide: `docs/UBUNTU_DEPLOYMENT.md`
- Complete documentation: `docs/HANDOVER.md`
- Troubleshooting: Check `pm2 logs`

## Total Time: ~15 minutes

From zero to fully deployed SWIM system!
