#!/bin/bash

echo "🚀 Starting SWIM Mini - Full Stack..."

# Start all services
pm2 start registry/server.js --name "swim-registry"
pm2 start services/query/server.js --name "ff-ice-query"
pm2 start services/filing/server.js --name "ff-ice-filing"
pm2 start services/auth/server.js --name "swim-auth"
pm2 start services/discovery/server.js --name "swim-discovery"
pm2 start services/monitoring/server.js --name "swim-monitoring"
pm2 start services/management/server.js --name "swim-management"
pm2 start services/subscription/server.js --name "swim-subscription"
pm2 start node-red --name "swim-router"

echo "⏳ Waiting for services to start..."
sleep 5

# Register all services
echo "📝 Registering services to Registry..."

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "FF-ICE Query Service",
    "type": "ff-ice-query",
    "url": "http://localhost:8081/flight/query",
    "description": "Flight information query service"
  }' > /dev/null

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "FF-ICE Filing Service",
    "type": "ff-ice-filing",
    "url": "http://localhost:8082/filing/submit",
    "description": "Flight plan filing service"
  }' > /dev/null

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Auth Service",
    "type": "swim-auth",
    "url": "http://localhost:8083/auth",
    "description": "JWT authentication service"
  }' > /dev/null

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Discovery Service",
    "type": "swim-discovery",
    "url": "http://localhost:8084/discovery",
    "description": "Automatic service discovery"
  }' > /dev/null

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Monitoring Service",
    "type": "swim-monitoring",
    "url": "http://localhost:8085/monitoring",
    "description": "Health checks and metrics"
  }' > /dev/null

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Management Dashboard",
    "type": "swim-management",
    "url": "http://localhost:8086/management",
    "description": "Administration dashboard"
  }' > /dev/null

curl -s -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Subscription Service",
    "type": "swim-subscription",
    "url": "http://localhost:8087/subscription",
    "description": "Pub/Sub messaging"
  }' > /dev/null

echo ""
echo "✅ SWIM Mini Full Stack is running!"
echo ""
echo "📊 Access Points:"
echo "  • Management Dashboard:  http://localhost:8086"
echo "  • Node-RED Router:       http://localhost:1880"
echo "  • Service Registry:      http://localhost:8090/registry/services"
echo ""
echo "🔐 Security:"
echo "  • Auth Service:          http://localhost:8083/auth/login"
echo ""
echo "🛫 FF-ICE Services:"
echo "  • Query Service:         http://localhost:8081/flight/query"
echo "  • Filing Service:        http://localhost:8082/filing/submit"
echo ""
echo "🔍 Check status: pm2 list"
echo "📝 View logs: pm2 logs"
