# SWIM Mini - Handover Documentation

## Project Overview

This document describes the SWIM (System Wide Information Management) mini implementation that has been completed. SWIM is an aviation information management system based on ICAO/EUROCONTROL standards for sharing flight information between stakeholders.

## What Was Implemented

### Complete Architecture: 7 Core Services + 2 FF-ICE Services

#### Core SWIM Services (7/7)

1. **Service Registry** (Port 8090)
   - Location: `registry/server.js`
   - Purpose: Central catalog of all available services
   - Features: Service registration, discovery, and metadata management
   - Endpoints:
     - `GET /health` - Health check
     - `POST /registry/register` - Register new service
     - `GET /registry/services` - List all services
     - `GET /registry/find/:type` - Find services by type
     - `DELETE /registry/service/:id` - Remove service

2. **Service Router** (Port 1880)
   - Technology: Node-RED
   - Location: `config/node-red-flow.json`
   - Purpose: Routes messages between services with authentication and discovery
   - Features: JWT validation, automatic service discovery, metrics recording
   - Flow: Request → Auth → Discovery → Forward → Response

3. **Service Security/Authentication** (Port 8083)
   - Location: `services/auth/server.js`
   - Purpose: JWT-based authentication and authorization
   - Features: Login, token verification, token refresh
   - Default users:
     - `airline1 / pass123` (operator role)
     - `atm1 / pass456` (ATM role)
     - `admin / admin123` (admin role)

4. **Service Discovery** (Port 8084)
   - Location: `services/discovery/server.js`
   - Purpose: Automatic service discovery with health checking
   - Features: Caching (30s TTL), health checks, load balancing
   - Endpoints:
     - `GET /discovery/find/:type` - Find all services of type
     - `GET /discovery/best/:type` - Get best healthy service
     - `POST /discovery/refresh` - Clear cache

5. **Service Monitoring** (Port 8085)
   - Location: `services/monitoring/server.js`
   - Purpose: Health monitoring and Prometheus metrics
   - Features: Service health checks, performance metrics, uptime tracking
   - Endpoints:
     - `GET /metrics` - Prometheus metrics
     - `GET /monitoring/health-check` - Check all services
     - `POST /monitoring/record` - Record custom metrics

6. **Service Management** (Port 8086)
   - Location: `services/management/server.js`
   - Purpose: Administration dashboard for system overview
   - Features: Web UI, service status, configuration management
   - Access: http://localhost:8086

7. **Service Subscription** (Port 8087)
   - Location: `services/subscription/server.js`
   - Purpose: Pub/Sub messaging using MQTT
   - Features: Topic subscription, message publishing, event notifications
   - Requires: Mosquitto MQTT broker on port 1883

#### FF-ICE Application Services (2/2)

8. **FF-ICE Query Service** (Port 8081)
   - Location: `services/query/server.js`
   - Purpose: Query flight information
   - Features: Search by flight number, departure, arrival, GUFI
   - Sample data: 2 mock flights included

9. **FF-ICE Filing Service** (Port 8082)
   - Location: `services/filing/server.js`
   - Purpose: File flight plans
   - Features: Submit flight plans, generate GUFI, track filed flights

## Directory Structure

```
swim/
├── registry/                   # Service Registry
│   ├── server.js
│   └── package.json
├── services/
│   ├── auth/                   # Authentication Service
│   ├── discovery/              # Discovery Service
│   ├── filing/                 # FF-ICE Filing
│   ├── management/             # Management Dashboard
│   │   ├── server.js
│   │   ├── package.json
│   │   └── public/
│   │       └── index.html      # Web UI
│   ├── monitoring/             # Monitoring Service
│   ├── query/                  # FF-ICE Query
│   └── subscription/           # Pub/Sub Service
├── config/
│   └── node-red-flow.json      # Node-RED router configuration
├── tests/
│   └── e2e-test.sh             # End-to-end test script
├── docs/
│   ├── HANDOVER.md             # This file
│   └── UBUNTU_DEPLOYMENT.md    # Ubuntu deployment guide
├── logs/                       # Log directory
├── start-all.sh                # Startup script
└── register-services.sh        # Service registration script
```

## Technology Stack

- **Runtime**: Node.js 18.x LTS
- **Framework**: Express.js
- **Authentication**: JWT (jsonwebtoken)
- **Routing**: Node-RED
- **Monitoring**: Prometheus (prom-client)
- **Messaging**: MQTT (Mosquitto + mqtt.js)
- **Process Management**: PM2
- **Reverse Proxy**: Nginx (optional, for production)

## Key Features Implemented

### 1. Authentication Flow
- JWT-based authentication with 24-hour token expiry
- Role-based access control (operator, atm, admin)
- Token verification on all protected endpoints

### 2. Service Discovery
- Automatic discovery of healthy services
- 30-second cache with health checks
- Round-robin load balancing selection

### 3. Message Routing
- Node-RED flow handles routing logic
- Integrates authentication, discovery, and monitoring
- Automatic service URL resolution

### 4. Monitoring & Health
- Prometheus metrics for all services
- Automatic health checks every 30 seconds
- Service uptime and memory tracking

### 5. Management Dashboard
- Real-time service status display
- Web-based UI with auto-refresh
- System overview and configuration

### 6. Pub/Sub Messaging
- MQTT-based event distribution
- Topic-based subscriptions
- Flight status notifications

## Configuration Details

### Service Ports
- 8090: Service Registry
- 8081: FF-ICE Query
- 8082: FF-ICE Filing
- 8083: Authentication
- 8084: Discovery
- 8085: Monitoring
- 8086: Management Dashboard
- 8087: Subscription
- 1880: Node-RED Router
- 1883: MQTT Broker

### Environment Variables
All services use `PORT` environment variable for port configuration with defaults as listed above.

### Authentication Secret
Located in `services/auth/server.js`:
```javascript
const SECRET_KEY = 'SWIM-SECRET-2025-CHANGE-IN-PRODUCTION';
```
**IMPORTANT**: Change this in production!

## Testing

### E2E Test Script
Location: `tests/e2e-test.sh`

Tests the complete flow:
1. Authentication (login and get JWT)
2. Service discovery (find filing service)
3. Flight plan filing (submit new flight)
4. Notification publishing (MQTT)
5. Flight query (retrieve filed flight)
6. Health monitoring (check all services)

### Manual Testing

#### Test Authentication
```bash
curl -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}'
```

#### Test Query Service
```bash
TOKEN="your-jwt-token"
curl http://localhost:8081/flight/query?flightNumber=VN123 \
  -H "Authorization: Bearer $TOKEN"
```

#### Test Filing Service
```bash
TOKEN="your-jwt-token"
curl -X POST http://localhost:8082/filing/submit \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "TEST123",
    "departure": "VVNB",
    "arrival": "VVTS",
    "departureTime": "2025-10-16T10:00:00Z",
    "aircraftType": "A320"
  }'
```

## Scripts

### start-all.sh
Starts all services and registers them to the registry.
```bash
chmod +x start-all.sh
./start-all.sh
```

### register-services.sh
Registers all services to the registry (if services are already running).
```bash
chmod +x register-services.sh
./register-services.sh
```

### e2e-test.sh
Runs complete end-to-end test.
```bash
chmod +x tests/e2e-test.sh
./tests/e2e-test.sh
```

## Known Limitations

1. **In-Memory Storage**: All services use in-memory data structures. Data is lost on restart.
2. **No Database**: No persistent storage implemented.
3. **Mock MQTT**: Subscription service requires external Mosquitto broker.
4. **No Node-RED Auto-Config**: Node-RED flow must be manually imported.
5. **Self-Signed Certs**: HTTPS configuration uses self-signed certificates.
6. **Windows Scripts**: Shell scripts are for Linux/Mac. Need conversion for Windows.

## Production Readiness Gaps

### Security
- Change JWT secret key
- Implement proper certificate management
- Add rate limiting
- Enable CORS properly
- Implement proper password hashing (bcrypt)

### Scalability
- Add database layer (PostgreSQL/MongoDB)
- Implement Redis for caching
- Add message queue (RabbitMQ)
- Enable clustering
- Add load balancing

### Monitoring
- Set up Grafana dashboards
- Configure alerting
- Implement centralized logging
- Add distributed tracing

### Standards Compliance
- Implement FIXM XML parsing
- Add AIXM support
- Implement proper SWIM standards
- Add WXXM weather data support

## Next Steps for Production

1. **Database Integration**
   - Choose PostgreSQL or MongoDB
   - Implement data models
   - Add migration scripts

2. **Docker Containerization**
   - Create Dockerfiles for each service
   - Create docker-compose.yml
   - Set up container orchestration

3. **CI/CD Pipeline**
   - Set up automated testing
   - Configure deployment pipeline
   - Implement blue-green deployment

4. **Security Hardening**
   - Implement PKI/X.509 certificates
   - Add API rate limiting
   - Set up WAF (Web Application Firewall)
   - Enable security headers

5. **Standards Implementation**
   - Implement FIXM 4.3.0 schemas
   - Add XML/JSON validation
   - Implement SWIM information services

## Support and Maintenance

### Log Locations
- PM2 logs: `~/.pm2/logs/`
- Service logs: `logs/` directory
- Node-RED logs: `~/.node-red/`

### Common Commands
```bash
# View service status
pm2 list

# View logs
pm2 logs
pm2 logs swim-registry

# Restart service
pm2 restart swim-registry

# Stop all services
pm2 stop all

# Check service health
curl http://localhost:8090/health
```

### Troubleshooting

**Services won't start:**
- Check if ports are already in use: `netstat -tulpn | grep <port>`
- Verify Node.js is installed: `node --version`
- Check PM2 status: `pm2 list`

**Authentication fails:**
- Verify JWT secret is correct
- Check token expiry (24 hours)
- Ensure credentials are correct

**Services not discovered:**
- Check if services are registered: `curl http://localhost:8090/registry/services`
- Verify services are healthy: `curl http://localhost:8085/monitoring/health-check`
- Clear discovery cache: `curl -X POST http://localhost:8084/discovery/refresh`

**MQTT not working:**
- Verify Mosquitto is running: `systemctl status mosquitto`
- Check MQTT connection: `mosquitto_sub -t "swim/#"`
- Test MQTT publish: `mosquitto_pub -t "test" -m "hello"`

## Contact Information

For questions about the implementation:
- Review code comments in each service
- Check the swim_do.md specification document
- Refer to UBUNTU_DEPLOYMENT.md for deployment instructions

## Handover Checklist

- [x] All 7 core services implemented
- [x] Both FF-ICE services implemented
- [x] Node-RED routing flow configured
- [x] Startup scripts created
- [x] E2E test script created
- [x] Documentation completed
- [x] Ubuntu deployment guide created
- [ ] Dependencies installed on target Ubuntu server
- [ ] Services deployed and tested on Ubuntu
- [ ] Monitoring dashboards configured
- [ ] Backup procedures established
- [ ] Production secrets configured

---

**Document Version:** 1.0
**Date:** 2025-10-15
**Implementation Status:** Development Complete - Ready for Ubuntu Deployment
