# SWIM Mini - Ubuntu Deployment Guide

Complete step-by-step guide to deploy SWIM on an Ubuntu server.

## Prerequisites

- Ubuntu 20.04 LTS or 22.04 LTS
- Root or sudo access
- Minimum 2GB RAM, 2 CPU cores
- 10GB free disk space
- Internet connection

## Step 1: System Preparation

### 1.1 Update System

```bash
sudo apt update && sudo apt upgrade -y
```

### 1.2 Install Required Dependencies

```bash
# Install build essentials
sudo apt install -y build-essential curl wget git

# Install Node.js 18.x LTS
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version   # Should show v18.x.x
npm --version    # Should show 9.x.x or higher
```

### 1.3 Install PM2 Process Manager

```bash
sudo npm install -g pm2

# Verify installation
pm2 --version
```

### 1.4 Install Node-RED

```bash
sudo npm install -g --unsafe-perm node-red

# Verify installation
node-red --version
```

### 1.5 Install MQTT Broker (Mosquitto)

```bash
sudo apt install -y mosquitto mosquitto-clients

# Start and enable Mosquitto
sudo systemctl start mosquitto
sudo systemctl enable mosquitto

# Verify Mosquitto is running
sudo systemctl status mosquitto
```

### 1.6 Install Optional Tools

```bash
# Install jq for JSON parsing
sudo apt install -y jq

# Install nginx for reverse proxy (optional)
sudo apt install -y nginx

# Install SSL tools
sudo apt install -y openssl
```

## Step 2: Transfer Source Code to Ubuntu

### Option A: Using Git (Recommended)

```bash
# Clone or copy your repository
cd ~
git clone <your-repository-url> swim-mini
cd swim-mini
```

### Option B: Using SCP from Windows

On your Windows machine:
```powershell
# Compress the swim directory first
cd D:\Projects
tar -czf swim.tar.gz swim

# Transfer to Ubuntu (replace with your server details)
scp swim.tar.gz user@ubuntu-server-ip:/home/user/
```

On Ubuntu:
```bash
cd ~
tar -xzf swim.tar.gz
mv swim swim-mini
cd swim-mini
```

### Option C: Using SFTP Client (WinSCP, FileZilla)

1. Connect to your Ubuntu server via SFTP
2. Upload the entire `swim` directory to `/home/your-user/swim-mini`
3. SSH into the server and navigate to the directory

## Step 3: Install Service Dependencies

Install Node.js dependencies for each service:

```bash
cd ~/swim-mini

# Registry
cd registry
npm install
cd ..

# Query Service
cd services/query
npm install
cd ../..

# Filing Service
cd services/filing
npm install
cd ../..

# Auth Service
cd services/auth
npm install
cd ../..

# Discovery Service
cd services/discovery
npm install
cd ../..

# Monitoring Service
cd services/monitoring
npm install
cd ../..

# Management Service
cd services/management
npm install
cd ../..

# Subscription Service
cd services/subscription
npm install
cd ../..
```

Or use this automated script:

```bash
cd ~/swim-mini

# Create install script
cat > install-deps.sh << 'EOF'
#!/bin/bash
echo "Installing dependencies for all services..."

services=(
    "registry"
    "services/query"
    "services/filing"
    "services/auth"
    "services/discovery"
    "services/monitoring"
    "services/management"
    "services/subscription"
)

for service in "${services[@]}"; do
    echo "Installing $service..."
    cd ~/swim-mini/$service
    npm install
done

echo "✅ All dependencies installed!"
EOF

chmod +x install-deps.sh
./install-deps.sh
```

## Step 4: Configure Services

### 4.1 Update File Permissions for Scripts

```bash
cd ~/swim-mini
chmod +x start-all.sh
chmod +x register-services.sh
chmod +x tests/e2e-test.sh
```

### 4.2 Configure Environment (Optional)

Create a `.env` file for production settings:

```bash
cd ~/swim-mini
cat > .env << EOF
# Environment Configuration
NODE_ENV=production

# Service Ports
PORT_REGISTRY=8090
PORT_QUERY=8081
PORT_FILING=8082
PORT_AUTH=8083
PORT_DISCOVERY=8084
PORT_MONITORING=8085
PORT_MANAGEMENT=8086
PORT_SUBSCRIPTION=8087

# Security
JWT_SECRET=YOUR-STRONG-SECRET-KEY-CHANGE-THIS

# MQTT
MQTT_BROKER=mqtt://localhost:1883
EOF
```

### 4.3 Update Auth Secret (IMPORTANT!)

Edit the auth service to use a strong secret:

```bash
nano ~/swim-mini/services/auth/server.js
```

Change this line:
```javascript
const SECRET_KEY = 'SWIM-SECRET-2025-CHANGE-IN-PRODUCTION';
```

To something secure:
```javascript
const SECRET_KEY = process.env.JWT_SECRET || 'your-very-strong-random-secret-key';
```

Generate a strong secret:
```bash
openssl rand -base64 32
```

## Step 5: Configure Node-RED

### 5.1 Start Node-RED Once to Create Config

```bash
node-red
# Press Ctrl+C after it starts successfully
```

### 5.2 Import SWIM Router Flow

```bash
# Copy the flow to Node-RED directory
cp ~/swim-mini/config/node-red-flow.json ~/.node-red/flows.json
```

Or manually:
1. Start Node-RED: `node-red`
2. Open browser: http://your-server-ip:1880
3. Click menu (≡) → Import
4. Paste contents from `config/node-red-flow.json`
5. Click Import

### 5.3 Install Node-RED Dependencies

```bash
cd ~/.node-red
npm install node-red-contrib-xml node-red-dashboard
```

## Step 6: Start All Services

### 6.1 Start Services with PM2

```bash
cd ~/swim-mini

# Start all services
pm2 start registry/server.js --name "swim-registry"
pm2 start services/query/server.js --name "ff-ice-query"
pm2 start services/filing/server.js --name "ff-ice-filing"
pm2 start services/auth/server.js --name "swim-auth"
pm2 start services/discovery/server.js --name "swim-discovery"
pm2 start services/monitoring/server.js --name "swim-monitoring"
pm2 start services/management/server.js --name "swim-management"
pm2 start services/subscription/server.js --name "swim-subscription"
pm2 start node-red --name "swim-router"

# Save PM2 configuration
pm2 save

# Enable PM2 to start on boot
pm2 startup
# Follow the instructions printed by the command above
```

### 6.2 Verify All Services Are Running

```bash
pm2 list
```

Expected output:
```
┌────┬─────────────────┬─────────┬─────────┬──────────┐
│ id │ name            │ status  │ restart │ uptime   │
├────┼─────────────────┼─────────┼─────────┼──────────┤
│ 0  │ swim-registry   │ online  │ 0       │ 2m       │
│ 1  │ ff-ice-query    │ online  │ 0       │ 2m       │
│ 2  │ ff-ice-filing   │ online  │ 0       │ 2m       │
│ 3  │ swim-auth       │ online  │ 0       │ 2m       │
│ 4  │ swim-discovery  │ online  │ 0       │ 2m       │
│ 5  │ swim-monitoring │ online  │ 0       │ 2m       │
│ 6  │ swim-management │ online  │ 0       │ 2m       │
│ 7  │ swim-subscription│ online  │ 0       │ 2m       │
│ 8  │ swim-router     │ online  │ 0       │ 2m       │
└────┴─────────────────┴─────────┴─────────┴──────────┘
```

### 6.3 Check Service Logs

```bash
# View all logs
pm2 logs

# View specific service logs
pm2 logs swim-registry
pm2 logs swim-auth
```

## Step 7: Register Services to Registry

Wait 10 seconds for all services to fully start, then register them:

```bash
cd ~/swim-mini
./register-services.sh
```

Or manually:
```bash
cd ~/swim-mini

# Register Query Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "FF-ICE Query Service",
    "type": "ff-ice-query",
    "url": "http://localhost:8081/flight/query",
    "description": "Flight information query service"
  }'

# Register Filing Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "FF-ICE Filing Service",
    "type": "ff-ice-filing",
    "url": "http://localhost:8082/filing/submit",
    "description": "Flight plan filing service"
  }'

# Continue with other services (see register-services.sh)
```

## Step 8: Verify Deployment

### 8.1 Check Service Health

```bash
# Check each service
curl http://localhost:8090/health  # Registry
curl http://localhost:8081/health  # Query
curl http://localhost:8082/health  # Filing
curl http://localhost:8083/health  # Auth
curl http://localhost:8084/health  # Discovery
curl http://localhost:8085/health  # Monitoring
curl http://localhost:8086/health  # Management
curl http://localhost:8087/health  # Subscription

# Check all services via monitoring
curl http://localhost:8085/monitoring/health-check | jq
```

### 8.2 Check Registry

```bash
curl http://localhost:8090/registry/services | jq
```

You should see all 7 services registered.

### 8.3 Test Authentication

```bash
# Login and get token
curl -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}' | jq

# Save the token for further tests
TOKEN=$(curl -s -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}' | jq -r '.token')

echo "Token: $TOKEN"
```

### 8.4 Test Flight Query

```bash
curl "http://localhost:8081/flight/query?flightNumber=VN123" \
  -H "Authorization: Bearer $TOKEN" | jq
```

### 8.5 Test Flight Filing

```bash
curl -X POST http://localhost:8082/filing/submit \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "TEST123",
    "departure": "VVNB",
    "arrival": "VVTS",
    "departureTime": "2025-10-16T10:00:00Z",
    "aircraftType": "A320"
  }' | jq
```

### 8.6 Run E2E Test

```bash
cd ~/swim-mini
./tests/e2e-test.sh
```

## Step 9: Configure Firewall

### 9.1 Enable UFW Firewall

```bash
sudo ufw enable
```

### 9.2 Allow Required Ports

```bash
# SSH (important - don't lock yourself out!)
sudo ufw allow 22/tcp

# SWIM Services
sudo ufw allow 8080:8090/tcp   # Service ports
sudo ufw allow 1880/tcp         # Node-RED
sudo ufw allow 1883/tcp         # MQTT

# Optional: HTTP/HTTPS for Nginx
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Check status
sudo ufw status
```

### 9.3 For Cloud Servers

If deploying on AWS, Azure, or GCP:
- Configure Security Groups/Network Security Groups
- Allow inbound traffic on ports: 8080-8090, 1880, 1883
- Consider using a VPN for production

## Step 10: Configure Nginx Reverse Proxy (Optional)

For production, use Nginx as a reverse proxy with HTTPS.

### 10.1 Create SSL Certificate

```bash
# Create directory
sudo mkdir -p /etc/ssl/swim

# Generate self-signed certificate (for testing)
sudo openssl req -x509 -nodes -days 365 \
  -newkey rsa:2048 \
  -keyout /etc/ssl/swim/swim.key \
  -out /etc/ssl/swim/swim.crt \
  -subj "/C=VN/ST=Hanoi/L=Hanoi/O=SWIM-Mini/CN=your-domain.com"

# For production, use Let's Encrypt:
# sudo apt install certbot python3-certbot-nginx
# sudo certbot --nginx -d your-domain.com
```

### 10.2 Configure Nginx

```bash
sudo nano /etc/nginx/sites-available/swim
```

Paste this configuration:

```nginx
upstream node_red {
    server 127.0.0.1:1880;
}

upstream registry {
    server 127.0.0.1:8090;
}

upstream management {
    server 127.0.0.1:8086;
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

# HTTPS Server
server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/ssl/swim/swim.crt;
    ssl_certificate_key /etc/ssl/swim/swim.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # SWIM Router
    location /swim/ {
        proxy_pass http://node_red/swim/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Registry API
    location /registry/ {
        proxy_pass http://registry/registry/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Management Dashboard
    location / {
        proxy_pass http://management/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Node-RED Editor
    location /node-red/ {
        proxy_pass http://node_red/;
        proxy_set_header Host $host;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

### 10.3 Enable Nginx Configuration

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/swim /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

## Step 11: Monitoring and Maintenance

### 11.1 View Logs

```bash
# PM2 logs
pm2 logs
pm2 logs swim-registry --lines 100

# Mosquitto logs
sudo journalctl -u mosquitto -f

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### 11.2 Service Management

```bash
# Restart a service
pm2 restart swim-registry

# Stop a service
pm2 stop swim-registry

# Start a service
pm2 start swim-registry

# Restart all services
pm2 restart all

# Stop all services
pm2 stop all
```

### 11.3 System Monitoring

```bash
# View PM2 monitoring
pm2 monit

# Check system resources
htop  # Install with: sudo apt install htop

# Check disk usage
df -h

# Check memory usage
free -h
```

### 11.4 Log Rotation

Configure PM2 log rotation:

```bash
pm2 install pm2-logrotate
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 7
```

## Step 12: Backup and Recovery

### 12.1 Backup Script

Create a backup script:

```bash
cat > ~/swim-backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR=~/swim-backups
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup source code
tar -czf $BACKUP_DIR/swim-source-$DATE.tar.gz ~/swim-mini

# Backup PM2 configuration
pm2 save

# Copy PM2 config
cp -r ~/.pm2 $BACKUP_DIR/pm2-$DATE

# Backup Node-RED flows
cp ~/.node-red/flows.json $BACKUP_DIR/node-red-flows-$DATE.json

echo "✅ Backup completed: $BACKUP_DIR"

# Keep only last 7 backups
ls -t $BACKUP_DIR/swim-source-*.tar.gz | tail -n +8 | xargs rm -f
EOF

chmod +x ~/swim-backup.sh
```

### 12.2 Schedule Automated Backups

```bash
# Add to crontab
crontab -e

# Add this line (backup daily at 2 AM)
0 2 * * * ~/swim-backup.sh
```

## Step 13: Production Hardening (Recommended)

### 13.1 Change Default Credentials

Update auth service to use strong passwords:

```bash
nano ~/swim-mini/services/auth/server.js
```

Change the users object with strong passwords.

### 13.2 Enable Node-RED Authentication

```bash
# Generate password hash
node-red-admin hash-pw

# Edit settings
nano ~/.node-red/settings.js
```

Add authentication section (example in swim_do.md).

### 13.3 Configure CORS

Update each service to enable CORS properly for your domain.

### 13.4 Enable Rate Limiting

Install and configure rate limiting middleware in each service.

### 13.5 Regular Updates

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Update Node.js packages
cd ~/swim-mini
npm outdated  # Check for updates
```

## Troubleshooting

### Services Won't Start

```bash
# Check PM2 logs
pm2 logs

# Check port conflicts
sudo netstat -tulpn | grep :8090

# Restart PM2
pm2 kill
pm2 resurrect
```

### MQTT Connection Issues

```bash
# Check Mosquitto status
sudo systemctl status mosquitto

# Restart Mosquitto
sudo systemctl restart mosquitto

# Test MQTT
mosquitto_pub -t "test" -m "hello"
mosquitto_sub -t "test"
```

### Memory Issues

```bash
# Check memory
free -h

# Increase swap if needed
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

### Node-RED Not Accessible

```bash
# Check if running
pm2 list | grep swim-router

# Restart Node-RED
pm2 restart swim-router

# Check logs
pm2 logs swim-router
```

## Access Points

After successful deployment, access:

- **Management Dashboard**: http://your-server-ip:8086
- **Node-RED**: http://your-server-ip:1880
- **Service Registry**: http://your-server-ip:8090/registry/services
- **Monitoring**: http://your-server-ip:8085/monitoring/health-check

With Nginx:
- **HTTPS Management**: https://your-domain.com
- **HTTPS Registry**: https://your-domain.com/registry/services
- **Node-RED Editor**: https://your-domain.com/node-red

## Quick Reference Commands

```bash
# Service Management
pm2 list                      # List all services
pm2 logs                      # View all logs
pm2 restart all               # Restart all services
pm2 stop all                  # Stop all services

# Health Checks
curl http://localhost:8090/health                    # Registry
curl http://localhost:8085/monitoring/health-check   # All services

# View Registered Services
curl http://localhost:8090/registry/services | jq

# Test Authentication
curl -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}'

# Run E2E Test
cd ~/swim-mini && ./tests/e2e-test.sh

# Backup
~/swim-backup.sh

# Update system
sudo apt update && sudo apt upgrade -y
```

## Support

For issues during deployment:

1. Check PM2 logs: `pm2 logs`
2. Verify all services are running: `pm2 list`
3. Test individual services: `curl http://localhost:<port>/health`
4. Review documentation: `~/swim-mini/docs/HANDOVER.md`
5. Run E2E test: `~/swim-mini/tests/e2e-test.sh`

---

**Document Version:** 1.0
**Deployment Target:** Ubuntu 20.04/22.04 LTS
**Last Updated:** 2025-10-15
