const express = require('express');
const app = express();
const PORT = process.env.PORT || 8090;

// In-memory service registry
let services = [];
let serviceId = 1;

app.use(express.json());

// Middleware logging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Register new service
app.post('/registry/register', (req, res) => {
  const { name, type, url, description } = req.body;

  if (!name || !type || !url) {
    return res.status(400).json({
      error: 'Missing required fields: name, type, url'
    });
  }

  const service = {
    id: serviceId++,
    name,
    type,
    url,
    description: description || '',
    registeredAt: new Date().toISOString(),
    status: 'active'
  };

  services.push(service);
  console.log(`✅ Registered: ${service.name} (${service.type})`);

  res.status(201).json({
    status: 'registered',
    service
  });
});

// List all services
app.get('/registry/services', (req, res) => {
  res.json({
    total: services.length,
    services
  });
});

// Find service by type
app.get('/registry/find/:type', (req, res) => {
  const found = services.filter(s => s.type === req.params.type);
  res.json({
    type: req.params.type,
    count: found.length,
    services: found
  });
});

// Find service by ID
app.get('/registry/service/:id', (req, res) => {
  const service = services.find(s => s.id === parseInt(req.params.id));
  if (service) {
    res.json(service);
  } else {
    res.status(404).json({ error: 'Service not found' });
  }
});

// Delete service
app.delete('/registry/service/:id', (req, res) => {
  const index = services.findIndex(s => s.id === parseInt(req.params.id));
  if (index !== -1) {
    const removed = services.splice(index, 1)[0];
    console.log(`🗑️ Removed: ${removed.name}`);
    res.json({ status: 'removed', service: removed });
  } else {
    res.status(404).json({ error: 'Service not found' });
  }
});

app.listen(PORT, () => {
  console.log(`📚 SWIM Service Registry running on port ${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/health`);
  console.log(`   Services: http://localhost:${PORT}/registry/services`);
});
