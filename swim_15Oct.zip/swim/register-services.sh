#!/bin/bash

echo "📝 Registering all services to Registry..."

# Query Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "FF-ICE Query Service",
    "type": "ff-ice-query",
    "url": "http://localhost:8081/flight/query",
    "description": "Flight information query service"
  }'

echo ""

# Filing Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "FF-ICE Filing Service",
    "type": "ff-ice-filing",
    "url": "http://localhost:8082/filing/submit",
    "description": "Flight plan filing service"
  }'

echo ""

# Auth Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Auth Service",
    "type": "swim-auth",
    "url": "http://localhost:8083/auth",
    "description": "JWT authentication service"
  }'

echo ""

# Discovery Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Discovery Service",
    "type": "swim-discovery",
    "url": "http://localhost:8084/discovery",
    "description": "Automatic service discovery"
  }'

echo ""

# Monitoring Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Monitoring Service",
    "type": "swim-monitoring",
    "url": "http://localhost:8085/monitoring",
    "description": "Health checks and metrics"
  }'

echo ""

# Management Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Management Dashboard",
    "type": "swim-management",
    "url": "http://localhost:8086/management",
    "description": "Administration dashboard"
  }'

echo ""

# Subscription Service
curl -X POST http://localhost:8090/registry/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "SWIM Subscription Service",
    "type": "swim-subscription",
    "url": "http://localhost:8087/subscription",
    "description": "Pub/Sub messaging"
  }'

echo ""
echo "✅ All services registered!"
