# SWIM Mini - Complete Implementation

A complete implementation of SWIM (System Wide Information Management) architecture based on ICAO/EUROCONTROL standards for aviation information sharing.

## Overview

SWIM Mini is a fully functional, development-ready implementation of the SWIM architecture featuring all 7 core services plus FF-ICE (Flight & Flow Information for a Collaborative Environment) application services.

## Architecture

### Core SWIM Services (7/7)

1. **Service Registry** (Port 8090) - Central service catalog
2. **Service Router** (Port 1880) - Node-RED message routing
3. **Service Security** (Port 8083) - JWT authentication
4. **Service Discovery** (Port 8084) - Automatic service discovery
5. **Service Monitoring** (Port 8085) - Health checks & Prometheus metrics
6. **Service Management** (Port 8086) - Web-based admin dashboard
7. **Service Subscription** (Port 8087) - MQTT pub/sub messaging

### FF-ICE Application Services (2/2)

8. **FF-ICE Query Service** (Port 8081) - Flight information queries
9. **FF-ICE Filing Service** (Port 8082) - Flight plan filing

## Quick Start

### Prerequisites

- Node.js 18.x LTS
- npm 9.x or higher
- PM2 process manager
- Mosquitto MQTT broker

### Installation

```bash
# Install dependencies for all services
cd registry && npm install && cd ..
cd services/query && npm install && cd ../..
cd services/filing && npm install && cd ../..
cd services/auth && npm install && cd ../..
cd services/discovery && npm install && cd ../..
cd services/monitoring && npm install && cd ../..
cd services/management && npm install && cd ../..
cd services/subscription && npm install && cd ../..

# Make scripts executable
chmod +x start-all.sh
chmod +x register-services.sh
chmod +x tests/e2e-test.sh
```

### Start All Services

```bash
# Start all services and register them
./start-all.sh

# Check status
pm2 list

# View logs
pm2 logs
```

## Project Structure

```
swim/
├── registry/                   # Service Registry
│   ├── server.js
│   └── package.json
├── services/
│   ├── auth/                   # Authentication Service
│   ├── discovery/              # Discovery Service
│   ├── filing/                 # FF-ICE Filing
│   ├── management/             # Management Dashboard
│   ├── monitoring/             # Monitoring Service
│   ├── query/                  # FF-ICE Query
│   └── subscription/           # Pub/Sub Service
├── config/
│   └── node-red-flow.json      # Node-RED router configuration
├── tests/
│   └── e2e-test.sh             # End-to-end test script
├── docs/
│   ├── HANDOVER.md             # Complete handover documentation
│   └── UBUNTU_DEPLOYMENT.md    # Ubuntu deployment guide
├── start-all.sh                # Startup script
└── register-services.sh        # Service registration script
```

## Key Features

- **JWT Authentication**: Secure token-based authentication with role-based access
- **Service Discovery**: Automatic discovery with health checks and caching
- **Message Routing**: Node-RED flow for intelligent request routing
- **Health Monitoring**: Prometheus metrics and health checks
- **Pub/Sub Messaging**: MQTT-based event distribution
- **Web Dashboard**: Real-time service status and management
- **Process Management**: PM2 for service lifecycle management

## Testing

### Authentication Test

```bash
# Get JWT token
TOKEN=$(curl -s -X POST http://localhost:8083/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"airline1","password":"pass123"}' \
  | jq -r '.token')

echo "Token: $TOKEN"
```

### Query Flight Information

```bash
curl "http://localhost:8081/flight/query?flightNumber=VN123" \
  -H "Authorization: Bearer $TOKEN" | jq
```

### File Flight Plan

```bash
curl -X POST http://localhost:8082/filing/submit \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "flightNumber": "TEST123",
    "departure": "VVNB",
    "arrival": "VVTS",
    "departureTime": "2025-10-16T10:00:00Z",
    "aircraftType": "A320"
  }' | jq
```

### Run E2E Test

```bash
./tests/e2e-test.sh
```

## Access Points

- **Management Dashboard**: http://localhost:8086
- **Node-RED Editor**: http://localhost:1880
- **Service Registry**: http://localhost:8090/registry/services
- **Monitoring Health**: http://localhost:8085/monitoring/health-check
- **Prometheus Metrics**: http://localhost:8085/metrics

## Default Credentials

### Authentication Service Users

- **airline1** / pass123 (Operator role)
- **atm1** / pass456 (ATM role)
- **admin** / admin123 (Admin role)

**IMPORTANT**: Change these credentials before production deployment!

## Service Management

### PM2 Commands

```bash
# List all services
pm2 list

# View logs
pm2 logs
pm2 logs swim-registry

# Restart service
pm2 restart swim-registry

# Stop service
pm2 stop swim-registry

# Restart all
pm2 restart all

# Stop all
pm2 stop all
```

### Health Checks

```bash
# Check individual service
curl http://localhost:8090/health

# Check all services
curl http://localhost:8085/monitoring/health-check | jq

# View registered services
curl http://localhost:8090/registry/services | jq
```

## Documentation

- **[HANDOVER.md](docs/HANDOVER.md)** - Complete handover documentation with implementation details
- **[UBUNTU_DEPLOYMENT.md](docs/UBUNTU_DEPLOYMENT.md)** - Step-by-step Ubuntu deployment guide

## Deployment

### For Ubuntu Server

See [UBUNTU_DEPLOYMENT.md](docs/UBUNTU_DEPLOYMENT.md) for complete deployment instructions including:

- System preparation
- Dependency installation
- Service configuration
- Nginx reverse proxy setup
- SSL/TLS configuration
- Firewall configuration
- Monitoring and maintenance
- Backup procedures

### Quick Deploy on Ubuntu

```bash
# 1. Transfer code to Ubuntu server
scp -r swim user@server:/home/user/swim-mini

# 2. SSH to server
ssh user@server

# 3. Run deployment
cd ~/swim-mini
./start-all.sh

# 4. Run tests
./tests/e2e-test.sh
```

## Technology Stack

- **Runtime**: Node.js 18.x
- **Framework**: Express.js
- **Authentication**: JWT (jsonwebtoken)
- **Routing**: Node-RED
- **Monitoring**: Prometheus (prom-client)
- **Messaging**: MQTT (Mosquitto + mqtt.js)
- **Process Manager**: PM2
- **Reverse Proxy**: Nginx (optional)

## Development

### Adding New Services

1. Create service directory under `services/`
2. Implement Express.js server with `/health` endpoint
3. Create `package.json` and install dependencies
4. Add service to `start-all.sh`
5. Register service in `register-services.sh`

### Extending FF-ICE

The architecture supports additional FF-ICE services:
- Planning Service
- Trial Request
- Preliminary Flight Plan
- Update/Cancel operations

## Production Considerations

### Security Hardening

- Change JWT secret key in `services/auth/server.js`
- Implement strong passwords for all users
- Enable HTTPS with valid SSL certificates
- Configure CORS appropriately
- Add rate limiting
- Enable Node-RED authentication

### Scalability

- Add PostgreSQL or MongoDB for persistence
- Implement Redis for caching
- Add RabbitMQ for message queuing
- Enable service clustering
- Configure load balancing

### Monitoring

- Set up Grafana dashboards
- Configure Prometheus alerting
- Implement centralized logging (ELK stack)
- Add distributed tracing (Jaeger)

### Standards Compliance

- Implement FIXM 4.3.0 XML schemas
- Add AIXM 5.1 support
- Implement WXXM 3.0 for weather
- Follow ICAO Doc 9965 guidelines

## Known Limitations

- In-memory storage (data lost on restart)
- No database persistence
- Self-signed SSL certificates
- Mock flight data
- Simplified authentication

## Contributing

To extend or modify SWIM Mini:

1. Review the architecture in `docs/HANDOVER.md`
2. Follow existing code patterns
3. Add tests for new features
4. Update documentation

## License

This is an educational/research implementation of SWIM architecture.

## Support

For questions and support:
- Review documentation in `docs/`
- Check logs: `pm2 logs`
- Run E2E tests: `./tests/e2e-test.sh`
- Verify health: `curl http://localhost:8085/monitoring/health-check`

## Acknowledgments

Based on ICAO/EUROCONTROL SWIM standards for aviation information management.

---

**Version**: 1.0.0
**Status**: Development Complete - Ready for Deployment
**Last Updated**: 2025-10-15
